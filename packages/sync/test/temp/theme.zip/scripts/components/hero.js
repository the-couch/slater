export default props => {
  console.log('hero fired', props)
}
